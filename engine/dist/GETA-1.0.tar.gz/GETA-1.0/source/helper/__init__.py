from load import load_image
import setter